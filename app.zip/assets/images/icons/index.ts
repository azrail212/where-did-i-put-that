export const icons = {
  livingRoom: require("./living-room.png"),
  bedroom: require("./bedroom.png"),
  kitchen: require("./kitchen.png"),
  bathroom: require("./bathtub.png"),
  childrenRoom: require("./children-room.png"),
  garage: require("./garage.png"),
  office: require("./workplace.png"),
  hallway: require("./hallway.png"),

  // future icons here
};

export default icons;
