# User Stories

## Add
- As a user, I want to add an item with its location so I can find it later.

## Find
- As a user, I want to search items by name so I can quickly locate them.

## Manage
- As a user, I want to delete an item so my list stays clean.
- As a user, I want to edit an item so the info stays accurate.
