# Roadmap

## v0.1 (MVP)
- [ ] Home screen: search + list
- [ ] Add Item screen
- [ ] Local persistence (AsyncStorage)
- [ ] Edit + Delete

## Later
- [ ] Rooms & boxes
- [ ] Photos
- [ ] Export/backup
- [ ] Sync
