# Data Model

## Item
- id: string
- name: string
- location: string
- createdAt: string (ISO)

## Storage
- Key: "items"
- Value: JSON array of Item
